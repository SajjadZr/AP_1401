package Controllers;

import Models.Airport;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DataBase {
    public static Airport loadUsers() {
        Airport AIRPORT = new Airport();
        try {
            String json = new String(Files.readAllBytes(Paths.get("DataBase.json")));
            AIRPORT = new Gson().fromJson(json, new TypeToken<Airport>() {
            }.getType());
        } catch (Exception e) {
            File file = new File("DataBase.json");
            try {
                file.createNewFile();
                AIRPORT = new Airport();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return AIRPORT;
    }

    public static void saveData(Airport airport) {
        FileWriter fileWriter;
        try {
            fileWriter = new FileWriter("DataBase.json");
            fileWriter.write(new Gson().toJson(airport));
            fileWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

