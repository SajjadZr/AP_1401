package Views;

import Controllers.DataBase;
import Controllers.ProgramController;
import Models.Airport;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RegisterMenu {
    private Airport airport;
    private ProgramController programController;

    public RegisterMenu(){
        //this.airport = new Airport();
        this.airport = DataBase.loadUsers();
        this.programController = new ProgramController(this.airport);
    }

    public void run() {
        String order;
        Scanner scanner = new Scanner(System.in);
        String userRegex = "\\s*register\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*";
        String adminRegex = "\\s*register\\s+as\\s+admin\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*";
        String loginRegex = "\\s*login\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*";
        String changeRegex = "\\s*change\\s+password\\s+(?<username>[a-zA-Z0-9_]*[a-zA-Z]+[a-zA-Z0-9_]*)\\s+(?<oldPassword>[a-zA-Z0-9_]+)\\s+(?<newPassword>\\S+)\\s*";
        String changeRegex2 = "\\s*change\\s+password\\s+(?<username>[a-zA-Z0-9_]*[a-zA-Z]+[a-zA-Z0-9_]*)\\s+(?<oldPassword>[a-zA-Z0-9_]+)\\s+(?<newPassword>[a-zA-Z0-9_]+)\\s*";
        String removeRegex = "\\s*remove\\s+account\\s+(?<username>[a-zA-Z0-9_]*[a-zA-Z]+[a-zA-Z0-9_]*)\\s+(?<password>[a-zA-Z0-9_]+)\\s*";
        String usernameRegex = "(?<username>[a-zA-Z0-9_]*[a-zA-Z]+[a-zA-Z0-9_]*)";
        String passwordRegex = "(?<password>[a-zA-Z0-9_]+)";
        String regexExit = "\\s*Exit\\s*";
        while (true) {
            order = scanner.nextLine().trim();
            if (getCommandMatcher(order, userRegex) != null) {
                Matcher matcher = getCommandMatcher(order, userRegex);
                if (getCommandMatcher(matcher.group(1), usernameRegex) == null) {
                    System.out.println("username format is invalid");
                } else if (airport.getUserByUsername(matcher.group(1)) != null) {
                    System.out.println("a user exists with this username");
                } else if (getCommandMatcher(matcher.group(2), passwordRegex) == null) {
                    System.out.println("password format is invalid");
                } else if (programController.isPasswordWeak(getCommandMatcher(matcher.group(2), passwordRegex))) {
                    System.out.println("password is weak");
                } else {
                    programController.addAccount(getCommandMatcher(matcher.group(1), usernameRegex), getCommandMatcher(matcher.group(2), passwordRegex), false);
                    System.out.println("register successful");
                }
            } else if (getCommandMatcher(order, adminRegex) != null) {
                Matcher matcher = getCommandMatcher(order, adminRegex);
                if (airport.getAdmin().getUsername() != null) {
                    System.out.println("admin user already created");
                } else if (getCommandMatcher(matcher.group(1), usernameRegex) == null) {
                    System.out.println("username format is invalid");
                } else if (airport.getUserByUsername(matcher.group(1)) != null) {
                    System.out.println("a user exists with this username");
                } else if (getCommandMatcher(matcher.group(2), passwordRegex) == null) {
                    System.out.println("password format is invalid");
                } else if (programController.isPasswordWeak(getCommandMatcher(matcher.group(2), passwordRegex))) {
                    System.out.println("password is weak");
                } else {
                    programController.addAccount(getCommandMatcher(matcher.group(1), usernameRegex), getCommandMatcher(matcher.group(2), passwordRegex), true);
                    System.out.println("admin user created successfully");
                }
            } else if (getCommandMatcher(order, loginRegex) != null) {
                Matcher matcher = getCommandMatcher(order, loginRegex);
                if (airport.getUserByUsername(matcher.group(1)) == null) {
                    System.out.println("no user exists with this username");
                } else if (!airport.getUserByUsername(matcher.group(1)).getPassword().equals(matcher.group(2))) {
                    System.out.println("incorrect password");
                } else {
                    System.out.println("login successful");
                    MainMenu mainMenu = new MainMenu(programController, airport, airport.getUserByUsername(matcher.group(1)));
                    mainMenu.run(scanner);
                }

            } else if (getCommandMatcher(order, changeRegex) != null) {
                Matcher matcher = getCommandMatcher(order, changeRegex);
                if (airport.getUserByUsername(matcher.group(1)) == null) {
                    System.out.println("no user exists with this username");
                } else if (!airport.getUserByUsername(matcher.group(1)).getPassword().equals(matcher.group(2))) {
                    System.out.println("incorrect password");
                } else if (getCommandMatcher(order, changeRegex2) == null) {
                    System.out.println("new password format is invalid");
                } else if (programController.isPasswordWeak(getCommandMatcher(matcher.group(3), passwordRegex))) {
                    System.out.println("new password is weak");
                } else {
                    airport.getUserByUsername(matcher.group(1)).setPassword(matcher.group(3), airport);
                    System.out.println("password changed successfully");
                }
            } else if (getCommandMatcher(order, removeRegex) != null) {
                Matcher matcher = getCommandMatcher(order, removeRegex);
                if (airport.getUserByUsername(matcher.group(1)) == null) {
                    System.out.println("no user exists with this username");
                } else if (!airport.getUserByUsername(matcher.group(1)).getPassword().equals(matcher.group(2))) {
                    System.out.println("incorrect password");
                } else {
                    programController.removeAccount(matcher.group(1));
                    System.out.println("account removed successfully");
                }
            } else if (getCommandMatcher(order, regexExit) != null) {
                scanner.close();
                break;
            } else {
                System.out.println("invalid command!");
            }
        }
    }

    protected Matcher getCommandMatcher(String order, String regex) {
        Matcher matcher = Pattern.compile(regex).matcher(order);
        return matcher.matches() ? matcher : null;
    }
}
