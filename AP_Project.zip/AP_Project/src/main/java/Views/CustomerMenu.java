package Views;

import Controllers.ProgramController;
import Models.Airport;
import Models.Flights;
import Models.IndirectFlights;
import Models.User;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;

public class CustomerMenu extends RegisterMenu {
    ProgramController programController;
    private Airport airport;
    private User user;

    public CustomerMenu(ProgramController programController, Airport airport, User user) {
        this.programController = programController;
        this.airport = airport;
        this.user = user;
    }

    public void run(Scanner scanner) {
        String order;
        String regexPurchase = "\\s*purchase\\s+ticket\\s+(?<origin>\\S+)\\s+(?<destination>\\S+)\\s*";
        String regexCharge = "\\s*charge\\s+account\\s+(?<amount>[-]?\\d+)\\s*";
        String regexCancel = "\\s*cancel\\s+ticket\\s*";
        String regexShow = "\\s*show\\s+capital\\s*";
        String regexBack = "\\s*back\\s*";
        while (true) {
            order = scanner.nextLine();
            if (getCommandMatcher(order, regexPurchase) != null) {
                Matcher matcher = getCommandMatcher(order, regexPurchase);
                ArrayList<Flights> specificFlights = programController.findSpecificOriginAndDestination(matcher.group(1), matcher.group(2));
                if (specificFlights.size() != 0) {
                    specificFlights = programController.sortArrayListOfFlights(specificFlights);
                    int numberOfFlights = 1;
                    for (Flights flights : specificFlights) {
                        System.out.println(numberOfFlights + "- " + flights.getDate() + " " + flights.getAirplaneName() + " " + flights.getTicketPrice());
                        numberOfFlights++;
                    }
                    while (true) {
                        order = scanner.nextLine();
                        String regexEnd = "\\s*end\\s*";
                        String regexOfNumber = "\\s*(?<number>[-]?\\d+)\\s*";
                        Flights specificFlight = new Flights();
                        boolean flag = true;
                        if (getCommandMatcher(order, regexEnd) != null) {
                            break;
                        } else if (getCommandMatcher(order, regexOfNumber) == null) {
                            System.out.println("invalid command!");
                        } else if (Integer.parseInt(getCommandMatcher(order, regexOfNumber).group(1)) < 1
                                || Integer.parseInt(getCommandMatcher(order, regexOfNumber).group(1)) > numberOfFlights - 1) {
                            System.out.println("invalid number");
                        } else {
                            int counterOfFlights = 1;
                            for (Flights flights : specificFlights) {
                                if (counterOfFlights == Integer.parseInt(getCommandMatcher(order, regexOfNumber).group(1))) {
                                    if (airport.getFlightByDateAndAirPlaneName(flights.getDate(), flights.getAirplaneName()) != null) {
                                        specificFlight = airport.getFlightByDateAndAirPlaneName(flights.getDate(), flights.getAirplaneName());
                                        if (specificFlight.getCapacity() == 0) {
                                            System.out.println("no empty seat");
                                            flag = false;
                                            break;
                                        }
                                    }
                                }
                                counterOfFlights++;
                            }
                            if (flag && user.getCapital() < specificFlight.getTicketPrice()) {
                                System.out.println("you don't have enough money");
                            } else if (flag && specificFlight.getDestination() != null) {
                                specificFlight.setCapacity(specificFlight.getCapacity() - 1);
                                user.addFlights(specificFlight, airport);
                                user.setCapital(user.getCapital() - specificFlight.getTicketPrice(), airport);
                                airport.setCapital(airport.getCapital() + specificFlight.getTicketPrice(), airport);
                                System.out.println("purchase successful");
                            }
                        }
                    }
                } else {
                    System.out.println("There is no direct flight from " + matcher.group(1) + " to " + matcher.group(2));
                    ArrayList<IndirectFlights> allIndirectFlights = new ArrayList<>();
                    allIndirectFlights = programController.findIndirectFlights(airport.getFlights(), matcher.group(1), matcher.group(2));
                    allIndirectFlights = programController.sortArrayListOfIndirectFlight(allIndirectFlights);
                    int numberOfIndirectFlights = 1;
                    boolean flag = false;
                    for (IndirectFlights indirectFlights : allIndirectFlights) {
                        System.out.println(numberOfIndirectFlights + "- " + indirectFlights.getOrigin() + "->" + indirectFlights.getThirdCity() + " "
                                + indirectFlights.getOriginFlightDate() + " " + indirectFlights.getOriginFlightTicketPrice() + " | " + indirectFlights.getThirdCity()
                                + "->" + indirectFlights.getDestination() + " "
                                + indirectFlights.getDestinationFlightDate() + " " + indirectFlights.getDestinationFlightTicketPrice());
                        numberOfIndirectFlights++;
                        flag = true;
                    }
                    while (flag) {
                        order = scanner.nextLine();
                        String regexEnd = "\\s*end\\s*";
                        String numberRegex = "\\s*(?<number>[-]?\\d+)\\s*";
                        Matcher matcher1 = getCommandMatcher(order, numberRegex);
                        IndirectFlights indirectFlight = new IndirectFlights();
                        if (getCommandMatcher(order, regexEnd) != null) {
                            break;
                        } else if (matcher1 == null) {
                            System.out.println("invalid command!");
                        } else if (Integer.parseInt(matcher1.group(1)) < 1 || Integer.parseInt(matcher1.group(1)) > numberOfIndirectFlights - 1) {
                            System.out.println("invalid number");
                        } else {
                            boolean flag1 = true;
                            int counter = 1;
                            for (IndirectFlights indirectFlights : allIndirectFlights) {
                                if (Integer.parseInt(matcher1.group(1)) == counter) {
                                    indirectFlight = indirectFlights;
                                    if (indirectFlight.getCapacityOfFirstFlight() == 0 || indirectFlight.getCapacityOfSecondFlight() == 0) {
                                        System.out.println("no empty seat");
                                        flag1 = false;
                                        break;
                                    }
                                }
                                counter++;
                            }
                            if (flag1 && indirectFlight.getDestinationFlightTicketPrice() + indirectFlight.getOriginFlightTicketPrice() > user.getCapital()) {
                                System.out.println("you don't have enough money");
                            } else if (flag1) {
                                user.addFlights(indirectFlight.getFirstFlight(), airport);
                                user.addFlights(indirectFlight.getSecondFlight(), airport);
                                user.setCapital(user.getCapital() - indirectFlight.getFirstFlight().getTicketPrice()
                                        - indirectFlight.getSecondFlight().getTicketPrice(), airport);
                                airport.setCapital(airport.getCapital() + indirectFlight.getFirstFlight().getTicketPrice()
                                        + indirectFlight.getSecondFlight().getTicketPrice(), airport);
                                indirectFlight.getFirstFlight().setCapacity(indirectFlight.getFirstFlight().getCapacity() - 1);
                                indirectFlight.getSecondFlight().setCapacity(indirectFlight.getSecondFlight().getCapacity() - 1);
                                System.out.println("purchase successful");
                            }
                        }
                    }
                }
            } else if (getCommandMatcher(order, regexCharge) != null) {
                if (Integer.parseInt(getCommandMatcher(order, regexCharge).group(1)) < 1) {
                    System.out.println("invalid amount");
                } else {
                    user.setCapital(user.getCapital() + Integer.parseInt(getCommandMatcher(order, regexCharge).group(1)), airport);
                    System.out.println("account charged successfully");
                }
            } else if (getCommandMatcher(order, regexCancel) != null) {
                int numberOfTicket = 1;
                boolean flag1 = false;
                for (Flights flights : user.getFlights()) {
                    System.out.println(numberOfTicket + "- " + flights.getOrigin() + "->" + flights.getDestination() + " " + flights.getDate()
                            + " " + flights.getTicketPrice());
                    numberOfTicket++;
                    flag1 = true;
                }
                while (flag1) {
                    boolean flag = false;
                    order = scanner.nextLine();
                    String endRegex = "\\s*end\\s*";
                    String numberRegex = "\\s*(?<number>[-]?\\d+)\\s*";
                    Matcher matcher = getCommandMatcher(order, numberRegex);
                    if (getCommandMatcher(order, endRegex) != null) {
                        break;
                    } else if (matcher == null) {
                        System.out.println("invalid command!");
                    } else if (Integer.parseInt(matcher.group(1)) < 1 || Integer.parseInt(matcher.group(1)) > numberOfTicket - 1) {
                        System.out.println("invalid number");
                    } else {
                        int counter = 1;
                        for (Flights flights : user.getFlights()) {
                            if (Integer.parseInt(matcher.group(1)) == counter) {
                                user.removeFlight(counter - 1, airport);
                                airport.getFlightByDateAndAirPlaneName(flights.getDate(), flights.getAirplaneName())
                                        .setCapacity(airport.getFlightByDateAndAirPlaneName(flights.getDate(), flights.getAirplaneName()).getCapacity() + 1);
                                airport.setCapital(airport.getCapital() - flights.getTicketPrice() + flights.getTicketPrice() * 20 / 100, airport);
                                user.setCapital(user.getCapital() + flights.getTicketPrice() - flights.getTicketPrice() * 20 / 100, airport);
                                System.out.println("cancel successful");
                                flag = true;
                                break;
                            }
                            counter++;
                        }
                    }
                    if (flag) break;
                }
                if (!flag1) System.out.println("you don't have any tickets");
            } else if (getCommandMatcher(order, regexShow) != null) {
                System.out.println(user.getCapital());
            } else if (getCommandMatcher(order, regexBack) != null) {
                break;
            } else {
                System.out.println("invalid command!");
            }
        }
    }
}
