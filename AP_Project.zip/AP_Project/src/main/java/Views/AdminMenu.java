package Views;

import Controllers.ProgramController;
import Models.Airplane;
import Models.Airport;
import Models.Flights;
import Models.User;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;

public class AdminMenu extends RegisterMenu {
    private ProgramController programController;
    private Airport airport;
    private User user;

    public AdminMenu(ProgramController programController, Airport airport, User user) {
        this.programController = programController;
        this.airport = airport;
        this.user = user;
    }

    public void run(Scanner scanner) {
        String order;
        String regexAddAirplane = "\\s*add\\s+airplane\\s+(?<name>\\S+)\\s+(?<capacity>[-]?\\d+)\\s*";
        String regexAddFlight = "\\s*add\\s+flight\\s+(?<origin>\\S+)\\s+(?<destination>\\S+)\\s+(?<date>\\d{4}-\\d{2}-\\d{2})\\s+(?<airplaneName>\\S+)\\s+(?<ticketPrice>[-]?\\d+)\\s*";
        String regexShowFlights = "\\s*show\\s+all\\s+flights\\s*";
        String regexShowFlightsOnDate = "\\s*show\\s+flights\\s+on\\s+(?<date>\\d{4}-\\d{2}-\\d{2})\\s*";
        String regexShowAirplanes = "\\s*show\\s+airplanes\\s*";
        String regexCapital = "\\s*show\\s+capital\\s*";
        String regexBack = "\\s*back\\s*";

        while (true) {
            order = scanner.nextLine();
            if (getCommandMatcher(order, regexAddAirplane) != null) {
                if (airport.getAirplaneByName(getCommandMatcher(order, regexAddAirplane).group(1)) != null) {
                    System.out.println("an airplane exists with this name");
                } else if (Integer.parseInt(getCommandMatcher(order, regexAddAirplane).group(2)) < 10) {
                    System.out.println("invalid capacity");
                } else {
                    programController.addAirplane(getCommandMatcher(order, regexAddAirplane));
                    System.out.println("plane created successfully ");
                }
            } else if (getCommandMatcher(order, regexAddFlight) != null) {
                Matcher matcher = getCommandMatcher(order, regexAddFlight);
                if (airport.getAirplaneByName(matcher.group(4)) == null) {
                    System.out.println("no airplane exists with this name");
                } else if (Integer.parseInt(matcher.group(5)) < 1) {
                    System.out.println("invalid ticket price");
                } else if (airport.getAirplaneByName(matcher.group(4)).getFlightByDate(matcher.group(3)) != null) {
                    System.out.println("This aircraft already has a flight on this date");
                } else {
                    programController.addFlight(matcher);
                    System.out.println("flight created successfully");
                }
            } else if (getCommandMatcher(order, regexShowFlights) != null) {
                ArrayList<Flights> allOfFlights = new ArrayList<>();
                allOfFlights = programController.sortArrayListOfFlights(airport.getFlights());
                boolean flag = true;
                int counterOfFlight = 1;
                for (Flights flights : allOfFlights) {
                    System.out.println(counterOfFlight + "- " + flights.getOrigin() + "->" + flights.getDestination() + " " + flights.getDate()
                            + " " + flights.getAirplaneName() + " " + flights.getTicketPrice());
                    counterOfFlight++;
                    flag = false;
                }
                if (flag) System.out.println("nothing");
            } else if (getCommandMatcher(order, regexShowFlightsOnDate) != null
                    && programController.isValidDate(getCommandMatcher(order, regexShowFlightsOnDate).group(1))) {
                ArrayList<Flights> flightsOfSpecificDate = programController.sortFlightsOnSpecificDate(getCommandMatcher(order, regexShowFlightsOnDate).group(1));
                boolean flag = true;
                int counterOfFlight = 1;
                for (Flights flights : flightsOfSpecificDate) {
                    System.out.println(counterOfFlight + "- " + flights.getOrigin() + "->" + flights.getDestination() + " " + flights.getDate()
                            + " " + flights.getAirplaneName() + " " + flights.getTicketPrice());
                    counterOfFlight++;
                    flag = false;
                }
                if (flag) System.out.println("nothing");
            } else if (getCommandMatcher(order, regexShowAirplanes) != null) {
                ArrayList<Airplane> airports = programController.sortAirplanes(airport.getAirplanes());
                boolean flag = true;
                int counterOfAirplane = 1;
                for (Airplane airplane : airports) {
                    System.out.println(counterOfAirplane + "- " + airplane.getName() + " : " + airplane.getNumberOfFlights());
                    counterOfAirplane++;
                    flag = false;
                }
                if (flag) System.out.println("nothing");
            } else if (getCommandMatcher(order, regexCapital) != null) {
                System.out.println(airport.getCapital());
            } else if (getCommandMatcher(order, regexBack) != null) {
                break;
            } else {
                System.out.println("invalid command!");
            }
        }
    }
}
