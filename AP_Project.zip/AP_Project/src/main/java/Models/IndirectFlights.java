package Models;

import Controllers.DataBase;

import java.io.Serial;
import java.io.Serializable;

public class IndirectFlights implements Serializable {
    @Serial
    private static final long serialVersionUID = 4585793542108L;
    private String origin;
    private String thirdCity;
    private String destination;
    private String originFlightDate;
    private String destinationFlightDate;
    private String nameOfFirstAirplane;
    private String nameOfSecondAirplane;
    private int originFlightTicketPrice;
    private int destinationFlightTicketPrice;
    private int capacityOfFirstFlight;
    private Flights firstFlight = new Flights();
    private Flights secondFlight = new Flights();

    public int getCapacityOfFirstFlight() {
        return capacityOfFirstFlight;
    }

    public void setCapacityOfFirstFlight(int capacityOfFirstFlight, Airport airport) {
        this.capacityOfFirstFlight = capacityOfFirstFlight;
        DataBase.saveData(airport);
    }

    public int getCapacityOfSecondFlight() {
        return capacityOfSecondFlight;
    }

    public void setCapacityOfSecondFlight(int capacityOfSecondFlight, Airport airport) {
        this.capacityOfSecondFlight = capacityOfSecondFlight;
        DataBase.saveData(airport);
    }

    private int capacityOfSecondFlight;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin, Airport airport) {
        this.origin = origin;
        DataBase.saveData(airport);
    }

    public String getThirdCity() {
        return thirdCity;
    }

    public void setThirdCity(String thirdCity, Airport airport) {
        this.thirdCity = thirdCity;
        DataBase.saveData(airport);
    }

    public void setNameOfFirstAirplane(String nameOfFirstAirplane, Airport airport) {
        this.nameOfFirstAirplane = nameOfFirstAirplane;
        DataBase.saveData(airport);
    }

    public String getNameOfFirstAirplane() {
        return this.nameOfFirstAirplane;
    }

    public void setNameOfSecondAirplane(String nameOfSecondAirplane, Airport airport) {
        this.nameOfSecondAirplane = nameOfSecondAirplane;
        DataBase.saveData(airport);
    }

    public String getNameOfSecondAirplane() {
        return this.nameOfSecondAirplane;
    }

    public String getDestination() {
        return destination;
    }

    public Flights getFirstFlight() {
        return firstFlight;
    }

    public void setFirstFlight(Flights firstFlight, Airport airport) {
        this.firstFlight = firstFlight;
        DataBase.saveData(airport);
    }

    public Flights getSecondFlight() {
        return secondFlight;
    }

    public void setSecondFlight(Flights secondFlight, Airport airport) {
        this.secondFlight = secondFlight;
        DataBase.saveData(airport);
    }

    public void setDestination(String destination, Airport airport) {
        this.destination = destination;
        DataBase.saveData(airport);
    }

    public String getOriginFlightDate() {
        return originFlightDate;
    }

    public void setOriginFlightDate(String originFlightDate, Airport airport) {
        this.originFlightDate = originFlightDate;
        DataBase.saveData(airport);
    }

    public String getDestinationFlightDate() {
        return destinationFlightDate;
    }

    public void setDestinationFlightDate(String destinationFlightDate, Airport airport) {
        this.destinationFlightDate = destinationFlightDate;
        DataBase.saveData(airport);
    }

    public int getOriginFlightTicketPrice() {
        return originFlightTicketPrice;
    }

    public void setOriginFlightTicketPrice(int originFlightTicketPrice, Airport airport) {
        this.originFlightTicketPrice = originFlightTicketPrice;
        DataBase.saveData(airport);
    }

    public int getDestinationFlightTicketPrice() {
        return destinationFlightTicketPrice;
    }

    public void setDestinationFlightTicketPrice(int destinationFlightTicketPrice, Airport airport) {
        this.destinationFlightTicketPrice = destinationFlightTicketPrice;
        DataBase.saveData(airport);
    }
}
