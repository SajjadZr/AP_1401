package Models;

import Controllers.DataBase;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable {
    @Serial
    private static final long serialVersionUID = 1469752830186457L;
    private String username;
    private String password;
    private int capital;
    private ArrayList<Flights> flights;

    public User() {
        this.flights = new ArrayList<>();
        this.username = null;
        this.password = null;
        this.capital = 0;
    }

    public void setCapital(int capital, Airport airport) {
        this.capital = capital;
        DataBase.saveData(airport);
    }

    public int getCapital() {
        return this.capital;
    }

    public void setUsername(String username, Airport airport) {
        this.username = username;
        DataBase.saveData(airport);
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password, Airport airport) {
        this.password = password;
        DataBase.saveData(airport);
    }

    public String getPassword() {
        return password;
    }

    public void addFlights(Flights flight, Airport airport) {
        flights.add(flight);
        DataBase.saveData(airport);
    }

    public ArrayList<Flights> getFlights() {
        return this.flights;
    }

    public void removeFlight(int index, Airport airport) {
        this.flights.remove(index);
        DataBase.saveData(airport);
    }
}
