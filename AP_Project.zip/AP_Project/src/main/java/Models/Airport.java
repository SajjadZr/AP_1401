package Models;

import Controllers.DataBase;

import java.util.ArrayList;

public class Airport {
    private User admin;
    private ArrayList<Flights> flights;
    private ArrayList<User> users;
    private ArrayList<Airplane> airplanes;
    private ArrayList<ArrayList<IndirectFlights>> indirectFlights;
    private int capital;

    public Airport() {
        this.capital = 0;
        this.flights = new ArrayList<>();
        this.admin = new User();
        this.users = new ArrayList<>();
        this.airplanes = new ArrayList<>();
        this.indirectFlights = new ArrayList<>();
    }

    public int getCapital() {
        return this.capital;
    }

    public void setCapital(int capital, Airport airport) {
        this.capital = capital;
        DataBase.saveData(airport);
    }

    public void setAdmin(User admin, Airport airport) {
        this.admin = admin;
        DataBase.saveData(airport);
    }

    public User getAdmin() {
        return this.admin;
    }

    public void addUser(User user, Airport airport) {
        this.users.add(user);
        DataBase.saveData(airport);
    }

    public void removeUsr(User user, Airport airport) {
        this.users.remove(user);
        DataBase.saveData(airport);
    }

    public User getUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public Airplane getAirplaneByName(String name) {
        for (Airplane airplane : airplanes) {
            if (airplane.getName().equals(name)) {
                return airplane;
            }
        }
        return null;
    }

    public void addAirplane(Airplane airplane, Airport airport) {
        this.airplanes.add(airplane);
        DataBase.saveData(airport);
    }

    public ArrayList<Airplane> getAirplanes() {
        return this.airplanes;
    }

    public void addFlight(Flights flight, Airport airport) {
        this.flights.add(flight);
        DataBase.saveData(airport);
    }

    public ArrayList<Flights> getFlights() {
        return this.flights;
    }

    public Flights getFlightByDateAndAirPlaneName(String date, String airplaneName) {
        for (Flights flights : flights) {
            if (flights.getDate().equals(date) && flights.getAirplaneName().equals(airplaneName))
                return flights;
        }
        return null;
    }

    public void removeAdmin(Airport airport) {
        this.admin.setUsername(null, airport);
        DataBase.saveData(airport);
    }
}
