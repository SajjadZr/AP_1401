package Controllers;

import Models.*;

import java.util.*;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProgramController {
    private Airport airport = new Airport();

    public ProgramController(Airport airport) {
        this.airport = airport;
    }

    public void addAccount(Matcher username, Matcher password, boolean flag) {
        User user = new User();
        user.setUsername(username.group(1));
        user.setPassword(password.group(1));
        airport.addUser(user);
        if (flag) {
            airport.setAdmin(user);
        }
    }

    public void removeAccount(String username) {
        User user = airport.getUserByUsername(username);
        airport.removeUsr(user);
        if (user.getUsername().equals(airport.getAdmin().getUsername())) {
            airport.removeAdmin();
        }
    }

    public boolean isPasswordWeak(Matcher matcher) {
        String regex1 = "(?<password>[a-zA-Z0-9_]*[a-z]+[a-zA-Z0-9_]*)";
        String regex2 = "(?<password>[a-zA-Z0-9_]*[A-Z]+[a-zA-Z0-9_]*)";
        String regex3 = "(?<password>[a-zA-Z0-9_]*[0-9]+[a-zA-Z0-9_]*)";
        if (matcher.group(1).length() > 4 && getCommandMatcher(matcher.group(1), regex1) != null
                && getCommandMatcher(matcher.group(1), regex2) != null && getCommandMatcher(matcher.group(1), regex3) != null) {
            return false;
        }
        return true;
    }

    public void addAirplane(Matcher matcher) {
        Airplane airplane = new Airplane();
        airplane.setName(matcher.group(1));
        airplane.setCapacity(Integer.parseInt(matcher.group(2)));
        airport.addAirplane(airplane);
    }

    public void addFlight(Matcher matcher) {
        Flights flight = new Flights();
        flight.setOrigin(matcher.group(1));
        flight.setDestination(matcher.group(2));
        flight.setDate(matcher.group(3));
        flight.setAirplaneName(matcher.group(4));
        flight.setTicketPrice(Integer.parseInt(matcher.group(5)));
        flight.setCapacity(airport.getAirplaneByName(matcher.group(4)).getCapacity());
        for (Airplane airplane : airport.getAirplanes()) {
            if (airplane.getName().equals(matcher.group(4))) {
                airplane.addFlight(flight);
            }
        }
        airport.addFlight(flight);
    }

    public ArrayList<Flights> sortArrayListOfFlights(ArrayList<Flights> flights) {
        Comparator<Flights> compare = Comparator.comparing(Flights::getDate).thenComparing(Flights::getTicketPrice)
                .thenComparing(Flights::getAirplaneName);
        Collections.sort(flights, compare);
        return flights;
    }

    public ArrayList<Flights> sortFlightsOnSpecificDate(String date) {
        ArrayList<Flights> flightsOnSpecificDate = new ArrayList<>();
        for (Flights flights : airport.getFlights()) {
            if (flights.getDate().equals(date)) {
                flightsOnSpecificDate.add(flights);
            }
        }
        return sortArrayListOfFlights(flightsOnSpecificDate);

    }

    public ArrayList<Airplane> sortAirplanes(ArrayList<Airplane> airplanes) {
        Comparator<Airplane> airplaneComparator = Comparator.comparing(Airplane::getName);
        Collections.sort(airplanes, airplaneComparator);
        return airplanes;
    }

    public ArrayList<Flights> findSpecificOriginAndDestination(String origin, String destination) {
        ArrayList<Flights> specificFlights = new ArrayList<>();
        for (Flights flights : airport.getFlights()) {
            if (flights.getOrigin().equals(origin) && flights.getDestination().equals(destination)) {
                specificFlights.add(flights);
            }
        }
        return specificFlights;
    }

    public ArrayList<IndirectFlights> findIndirectFlights(ArrayList<Flights> allFlights, String origin, String destination) {
        ArrayList<IndirectFlights> allIndirectFlights = new ArrayList<>();
        for (Flights originFlights : allFlights) {
            if (originFlights.getOrigin().equals(origin)) {
                for (Flights destinationFlights : allFlights) {
                    if (destinationFlights.getDestination().equals(destination) &&
                            destinationFlights.getOrigin().equals(originFlights.getDestination()) &&
                            checkDate(originFlights.getDate(), destinationFlights.getDate())) {
                        IndirectFlights indirectFlights = new IndirectFlights();
                        indirectFlights.setOrigin(origin);
                        indirectFlights.setDestination(destination);
                        indirectFlights.setThirdCity(originFlights.getDestination());
                        indirectFlights.setOriginFlightDate(originFlights.getDate());
                        indirectFlights.setDestinationFlightDate(destinationFlights.getDate());
                        indirectFlights.setOriginFlightTicketPrice(originFlights.getTicketPrice());
                        indirectFlights.setDestinationFlightTicketPrice(destinationFlights.getTicketPrice());
                        indirectFlights.setNameOfFirstAirplane(originFlights.getAirplaneName());
                        indirectFlights.setNameOfSecondAirplane(destinationFlights.getAirplaneName());
                        indirectFlights.setCapacityOfFirstFlight(originFlights.getCapacity());
                        indirectFlights.setCapacityOfSecondFlight(destinationFlights.getCapacity());
                        indirectFlights.setFirstFlight(originFlights);
                        indirectFlights.setSecondFlight(destinationFlights);
                        allIndirectFlights.add(indirectFlights);
                    }
                }
            }
        }
        return allIndirectFlights;
    }

    public boolean checkDate(String originFlightDate, String destinationFlightDate) {
        if (originFlightDate.equals(destinationFlightDate))
            return false;
        int firstDate = Integer.parseInt(originFlightDate.replaceAll("-", ""));
        int secondDate = Integer.parseInt(destinationFlightDate.replaceAll("-", ""));
        if (firstDate / 10000 > secondDate / 10000)
            return false;
        else if (firstDate / 10000 < secondDate / 10000) {
            return true;
        } else if (firstDate % 10000 / 100 > secondDate % 10000 / 100) {
            return false;
        } else if (firstDate % 10000 / 100 < secondDate % 10000 / 100) {
            return true;
        } else if (firstDate % 100 > secondDate % 100) {
            return false;
        } else
            return true;
    }

    public ArrayList<IndirectFlights> sortArrayListOfIndirectFlight(ArrayList<IndirectFlights> indirectFlights) {
        Comparator<IndirectFlights> comparator = Comparator.comparing(IndirectFlights::getOriginFlightDate).thenComparing(IndirectFlights::getOriginFlightTicketPrice)
                .thenComparing(IndirectFlights::getNameOfFirstAirplane).thenComparing(IndirectFlights::getDestinationFlightDate)
                .thenComparing(IndirectFlights::getDestinationFlightTicketPrice).thenComparing(IndirectFlights::getNameOfSecondAirplane);
        Collections.sort(indirectFlights, comparator);
        return indirectFlights;
    }

    public boolean isValidDate(String Date) {
        int date = Integer.parseInt(Date.replaceAll("-", ""));
        if (date % 100 > 30 || date % 100 < 1) {
            return false;
        } else if (date / 100 % 100 > 12 || date / 100 % 100 < 1) {
            return false;
        }
        return true;
    }

    private Matcher getCommandMatcher(String order, String regex) {
        Matcher matcher = Pattern.compile(regex).matcher(order);
        return matcher.matches() ? matcher : null;
    }

}
