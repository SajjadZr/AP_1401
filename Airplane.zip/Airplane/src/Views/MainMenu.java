package Views;

import Controllers.ProgramController;
import Models.Airport;
import Models.User;

import java.util.Scanner;

public class MainMenu extends RegisterMenu {
    private ProgramController programController;
    private User user;
    private Airport airport;

    public MainMenu(ProgramController programController, Airport airport, User user) {
        this.programController = programController;
        this.airport = airport;
        this.user = user;
    }

    public void run(Scanner scanner) {
        String order;
        String regexAdminMenu = "\\s*admin\\s+menu\\s*";
        String regexCustomerMenu = "\\s*customer\\s+menu\\s*";
        String regexLogout = "\\s*logout\\s*";
        while (true) {
            order = scanner.nextLine();
            if (getCommandMatcher(order, regexAdminMenu) != null) {
                if (!user.getUsername().equals(airport.getAdmin().getUsername())) {
                    System.out.println("you don't have access to this menu");
                } else {
                    AdminMenu adminMenu = new AdminMenu(programController, airport, user);
                    adminMenu.run(scanner);
                }
            } else if (getCommandMatcher(order, regexCustomerMenu) != null) {
                if (user.getUsername().equals(airport.getAdmin().getUsername())) {
                    System.out.println("you don't have access to this menu");
                } else {
                    CustomerMenu customerMenu = new CustomerMenu(programController, airport, user);
                    customerMenu.run(scanner);
                }
            } else if (getCommandMatcher(order, regexLogout) != null) {
                System.out.println("logout successful");
                break;
            } else {
                System.out.println("invalid command!");
            }
        }

    }
}
