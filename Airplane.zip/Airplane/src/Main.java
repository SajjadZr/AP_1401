// in the name of GOD

import Views.RegisterMenu;

public class Main {
    public static void main(String[] args) {
        RegisterMenu registerMenu = new RegisterMenu();
        registerMenu.run();
    }
}

