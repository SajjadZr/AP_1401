package Models;

import java.util.ArrayList;

public class User {
    private String username;
    private String password;
    private int capital;
    private ArrayList<Flights> flights;

    public User() {
        this.flights = new ArrayList<>();
        this.username = null;
        this.password = null;
        this.capital = 0;
    }

    public void setCapital(int capital) {
        this.capital = capital;
    }

    public int getCapital() {
        return this.capital;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void addFlights(Flights flight) {
        flights.add(flight);
    }

    public ArrayList<Flights> getFlights() {
        return this.flights;
    }

    public void removeFlight(int index) {
        this.flights.remove(index);
    }
}
