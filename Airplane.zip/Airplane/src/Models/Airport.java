package Models;

import java.util.ArrayList;

public class Airport {
    private User admin;
    private ArrayList<Flights> flights;
    private ArrayList<User> users;
    private ArrayList<Airplane> airplanes;
    private ArrayList<ArrayList<IndirectFlights>> indirectFlights;
    private int capital;

    public Airport() {
        this.capital = 0;
        this.flights = new ArrayList<>();
        this.admin = new User();
        this.users = new ArrayList<>();
        this.airplanes = new ArrayList<>();
        this.indirectFlights = new ArrayList<>();
    }

    public int getCapital() {
        return this.capital;
    }

    public void setCapital(int capital) {
        this.capital = capital;
    }

    public void setAdmin(User admin) {
        this.admin = admin;
    }

    public User getAdmin() {
        return this.admin;
    }

    public void addUser(User user) {
        this.users.add(user);
    }

    public void removeUsr(User user) {
        this.users.remove(user);
    }

    public User getUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public Airplane getAirplaneByName(String name) {
        for (Airplane airplane : airplanes) {
            if (airplane.getName().equals(name)) {
                return airplane;
            }
        }
        return null;
    }

    public void addAirplane(Airplane airplane) {
        this.airplanes.add(airplane);
    }

    public ArrayList<Airplane> getAirplanes() {
        return this.airplanes;
    }

    public void addFlight(Flights flight) {
        this.flights.add(flight);
    }

    public ArrayList<Flights> getFlights() {
        return this.flights;
    }

    public Flights getFlightByDateAndAirPlaneName(String date, String airplaneName) {
        for (Flights flights : flights) {
            if (flights.getDate().equals(date) && flights.getAirplaneName().equals(airplaneName))
                return flights;
        }
        return null;
    }

    public void removeAdmin() {
        this.admin.setUsername(null);
    }
}
