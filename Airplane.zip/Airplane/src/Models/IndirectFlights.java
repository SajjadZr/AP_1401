package Models;

public class IndirectFlights {
    private String origin;
    private String thirdCity;
    private String destination;
    private String originFlightDate;
    private String destinationFlightDate;
    private String nameOfFirstAirplane;
    private String nameOfSecondAirplane;
    private int originFlightTicketPrice;
    private int destinationFlightTicketPrice;
    private int capacityOfFirstFlight;
    private Flights firstFlight = new Flights();
    private Flights secondFlight = new Flights();

    public int getCapacityOfFirstFlight() {
        return capacityOfFirstFlight;
    }

    public void setCapacityOfFirstFlight(int capacityOfFirstFlight) {
        this.capacityOfFirstFlight = capacityOfFirstFlight;
    }

    public int getCapacityOfSecondFlight() {
        return capacityOfSecondFlight;
    }

    public void setCapacityOfSecondFlight(int capacityOfSecondFlight) {
        this.capacityOfSecondFlight = capacityOfSecondFlight;
    }

    private int capacityOfSecondFlight;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getThirdCity() {
        return thirdCity;
    }

    public void setThirdCity(String thirdCity) {
        this.thirdCity = thirdCity;
    }

    public void setNameOfFirstAirplane(String nameOfFirstAirplane) {
        this.nameOfFirstAirplane = nameOfFirstAirplane;
    }

    public String getNameOfFirstAirplane() {
        return this.nameOfFirstAirplane;
    }

    public void setNameOfSecondAirplane(String nameOfSecondAirplane) {
        this.nameOfSecondAirplane = nameOfSecondAirplane;
    }

    public String getNameOfSecondAirplane() {
        return this.nameOfSecondAirplane;
    }

    public String getDestination() {
        return destination;
    }

    public Flights getFirstFlight() {
        return firstFlight;
    }

    public void setFirstFlight(Flights firstFlight) {
        this.firstFlight = firstFlight;
    }

    public Flights getSecondFlight() {
        return secondFlight;
    }

    public void setSecondFlight(Flights secondFlight) {
        this.secondFlight = secondFlight;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getOriginFlightDate() {
        return originFlightDate;
    }

    public void setOriginFlightDate(String originFlightDate) {
        this.originFlightDate = originFlightDate;
    }

    public String getDestinationFlightDate() {
        return destinationFlightDate;
    }

    public void setDestinationFlightDate(String destinationFlightDate) {
        this.destinationFlightDate = destinationFlightDate;
    }

    public int getOriginFlightTicketPrice() {
        return originFlightTicketPrice;
    }

    public void setOriginFlightTicketPrice(int originFlightTicketPrice) {
        this.originFlightTicketPrice = originFlightTicketPrice;
    }

    public int getDestinationFlightTicketPrice() {
        return destinationFlightTicketPrice;
    }

    public void setDestinationFlightTicketPrice(int destinationFlightTicketPrice) {
        this.destinationFlightTicketPrice = destinationFlightTicketPrice;
    }
}
