package Models;

import java.util.ArrayList;

public class Airplane {
    private String name;
    private int capacity;
    private int numberOfFlights;
    private ArrayList<Flights> flights = new ArrayList<>();

    public Airplane() {
        this.numberOfFlights = 0;
    }

    public void setNumberOfFlights(int numberOfFlights) {
        this.numberOfFlights = numberOfFlights;
    }

    public int getNumberOfFlights() {
        return this.numberOfFlights;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void addFlight(Flights flight) {
        this.flights.add(flight);
        setNumberOfFlights(getNumberOfFlights() + 1);
    }

    public Flights getFlightByDate(String date) {
        for (Flights flights : flights) {
            if (flights.getDate().equals(date)) {
                return flights;
            }
        }
        return null;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getCapacity() {
        return this.capacity;
    }
}

